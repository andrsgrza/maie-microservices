package com.angaar.quiz_service.models.entitlements;

public enum ResourceType {
	QUIZ
}
