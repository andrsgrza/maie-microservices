package com.angaar.quiz_service.models.entitlements;

public enum Role {
	OWNER,
	READ_WRITE,
	READ_ONLY

}
