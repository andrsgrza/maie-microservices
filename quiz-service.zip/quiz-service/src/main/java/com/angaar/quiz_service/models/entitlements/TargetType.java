package com.angaar.quiz_service.models.entitlements;

public enum TargetType {
	USER,
	GLOBAL
}
