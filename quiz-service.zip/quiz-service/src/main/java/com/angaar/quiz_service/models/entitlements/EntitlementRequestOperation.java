package com.angaar.quiz_service.models.entitlements;

public enum EntitlementRequestOperation {
	CREATE, DELETE;
}
